##################################################
## Project: workshop
## Script purpose: install packages required for work shop
## Date: 03-03-2020
## Author: David JPO'Sullivan, Kevin Burke & Norma Bargary
##################################################

install.packages('tidyverse')
install.packages('broom')
install.packages('flex')
install.packages("flexdashboard")
install.packages('knitr')